/**
 * @file parser.c
 * @author xmikusm00
 * @brief expression parser header file
 */
#ifndef EXPR_PARSER_H
#define EXPR_PARSER_H
#include "scanner.h"
#include "symtable.h"
#include "expr_stack.h"
#include "expr_ast.h"


struct ASTNode* expression_parser_main(Token *token, int *error_code);



#endif //EXPR_PARSER_H
